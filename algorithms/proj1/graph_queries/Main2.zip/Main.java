import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Locale;
import java.io.IOException;

public class Main {

    public static void processCase(BufferedReader in, PrintStream out, int caseNum) throws IOException {
        boolean coms = true;
        double sum = 0;
        double count = 0;
        String line = in.readLine();
        String[] params = line.split("\\s+");
        int k = Integer.parseInt(params[0]);
        int m = Integer.parseInt(params[1]);
        int[] weights = new int[k];
        Edge[] edges = new Edge[m];
        ArrayList<Integer>[] vertices = new ArrayList[k];

        // Expect Vertices
        for (int i = 0; i < k; i++) {
            vertices[i] = new ArrayList<>();
            weights[i] = Integer.parseInt(in.readLine());
        }
        // Expect Edges
        for (int i = 0; i < m; i++) {
            line = in.readLine();
            params = line.trim().split("\\s+");
            int from = Integer.parseInt(params[0]) - 1;
            int to = Integer.parseInt(params[1]) - 1;

            // for linkedlist
            vertices[from].add(to);
            vertices[to].add(from);

            edges[i] = new Edge(from, to);
        }

        while (coms) {
            line = in.readLine();
            params = line.trim().split("\\s+");
            int command = Integer.parseInt(params[0]);
            switch (command) {
            // Terminate test case
            case 3:
                coms = false;
                break;
            // Delete X-th edge
            case 0:
                int x = Integer.parseInt(params[1]) - 1;
                // for linkedlist
                vertices[edges[x].getTo()].remove(edges[x].getFromObj());
                vertices[edges[x].getFrom()].remove(edges[x].getToObj());

                break;
            // Change Weight of vertex X to Y
            case 1:
                int vertex = Integer.parseInt(params[1]);
                int weight = Integer.parseInt(params[2]);
                weights[vertex - 1] = weight;
                break;
            // Fetch Weight of Y-th Largest vertex connected to X (illegal = 0)
            case 2:
                int vertex1 = Integer.parseInt(params[1]) - 1;
                int index = Integer.parseInt(params[2]);
                LinkedList<Integer> connected = new LinkedList<>();
                connected.add(weights[vertex1]);
                for (int i : vertices[vertex1]) {
                    connected.add(weights[i]);
                }
                if (index <= connected.size()) {
                    Collections.sort(connected);
                    sum += connected.get(connected.size() - index);
                    count++;
                } else {
                    count++;
                }
                break;
            }
        }
        out.print("" + caseNum + ": ");
        out.printf(Locale.US, "%.6f\n", sum / count);
    }
    public static void main(String[] argv) {
        
        InputStreamReader in = new InputStreamReader(System.in);
        BufferedReader s = new BufferedReader(in);

        try{
            int N = Integer.parseInt(s.readLine().trim());
            for (int i = 1; i <= N; i++) {
                processCase(s, System.out, i);
            }
        } catch(IOException e) {
            System.err.println("IOException");
        }
        
    }

}

class Edge {
    private Integer toObj;
    private Integer fromObj;

    public Edge(int from, int to) {
        this.toObj = Integer.valueOf(to);
        this.fromObj = Integer.valueOf(from);
    }

    public int getFrom() {
        return this.fromObj;
    }

    public int getTo() {
        return this.toObj;
    }

    public Integer getFromObj() {
        return this.fromObj;
    }

    public Integer getToObj() {
        return this.toObj;
    }
}