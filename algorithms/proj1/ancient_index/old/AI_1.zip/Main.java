import java.io.PrintStream;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import java.io.IOException;

public class Main {

    public static void processCase(Reader in, PrintStream out, int iteration) throws IOException {
        String output = "";
        HashSet<Character> characters = new HashSet<>();
        HashMap<Integer, Character> indexToChar = new HashMap<>();
        HashMap<Character, Integer> charToIndex = new HashMap<>();
        int wordCount = Integer.parseInt(in.readLine());
        

        // [Greater Than][Less Than]
        int[][] charAdjacency = new int[15][15];
        int charCount = 0;
        String firstWord = in.readLine();
        String secondWord;
        if (wordCount == 1) {
            int answer = factorial(firstWord.length());
            System.out.println("" + iteration + ": " + answer);    
            return;
        }

        for (int i = 0; i < wordCount - 1; i++) {
            secondWord = in.readLine();
            for (int j = 0; j < firstWord.length(); j++) {
                char currentChar = firstWord.charAt(j);
                // Check for new characters
                if (!characters.contains(currentChar)) {
                    // New Character
                    characters.add(currentChar);
                    charToIndex.put(currentChar, charCount);
                    indexToChar.put(charCount++, currentChar);
                }
                if (j < secondWord.length()) {
                    char newCurrentChar = secondWord.charAt(j);
                    if (!characters.contains(newCurrentChar)) {
                        characters.add(newCurrentChar);
                        charToIndex.put(newCurrentChar, charCount);
                        indexToChar.put(charCount++, newCurrentChar);
                    }
                }
                // TODO: Compare first word and second word
                char first = firstWord.charAt(j);
                char second;
                if (j < secondWord.length()) {
                    second = secondWord.charAt(j);
                    if (second != first) {
                        // Show adjacency, then move onto the next word
                        charAdjacency[charToIndex.get(first)][charToIndex.get(second)] = 1;
                        break;
                    }
                }
            }
            firstWord = secondWord;
        }

        // TODO: Create subgraphs from adjacency matrix
        Graph graph = new Graph(charCount);

        for (int i = 0; i < charCount; i++) {
            String adjacency = indexToChar.get(i) + ": ";
            for (int j = 0; j < charCount; j++) {
                if (charAdjacency[i][j] == 1) {
                    // Higher than these
                    adjacency += ">" + indexToChar.get(j) + "; ";
                    graph.addEdge(i,j);
                }
                if (charAdjacency[j][i] == 1) {
                    // Lower than these
                    adjacency += "<"+indexToChar.get(j) + "; ";
                }
            }
        }

        // TODO: Find possible combinatins of each graph through topologicl sorting

        // TODO: Merge all graphs together with maths

        // Print list of characters. TODO: Remove
        for (int a : graph.topologicalSort()){
            output += (indexToChar.get(a));
        }

        out.println("" + iteration + ": " + output);
    }

    public static void process(Reader in, PrintStream out) throws IOException {
        int N = Integer.parseInt(in.readLine());
        for (int i = 1; i <= N; i++) {
            processCase(in, out, i);
        }
    }
    
    public static int factorial(int n){    
        if (n == 0)    
          return 1;    
        else    
          return(n * factorial(n-1));    
       }  

    public static void main(String[] argv) throws IOException {
        process(new Reader(), System.out);
    }
}