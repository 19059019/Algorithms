import java.io.PrintStream;
import java.util.HashMap;
import java.awt.font.NumericShaper.Range;
import java.io.IOException;

public class Main {
    // Stores catalan numbers
    private static final int[] CAT_NUMS = getCats();
    private static HashMap<Integer, String[]> memoise = new HashMap<>();
    private static HashMap<Integer, String> dynamicMemoise = new HashMap<>();

    public static void processCase(Reader in, PrintStream out, int iteration) throws IOException {
        String output = "";
        int n = in.nextInt();
        if (dynamicMemoise.containsKey(n)) {
            output = dynamicMemoise.get(n);
        } else {
            output = getTree((int) n).replaceAll("\\(\\)", "");
            dynamicMemoise.put(n, output);
        }
        out.println("" + iteration + ": " + output);
    }

    public static String getTree(long n) {
        long position = 0;
        int nodes = 0;
        long previous = 0;
        // Find number of nodes needed to get to this number
        for (int l : CAT_NUMS) {
            if (position > n) {
                position = previous - (position - (int) n);
                break;
            } else {
                previous = l;
                position += l;
                nodes++;
            }
        }
        nodes--;
        int thisRange = CAT_NUMS[nodes];
        String out = "";
        if (memoise.get(nodes) == null) {
            int current = 0;
            int leftTree = 0;
            long leftTreePos = 0;
            long rightTreePos = 0;
            boolean stop = false;
            String left = "";
            String right = "";
            // Go through every node set until we reach the one that we want
            for (int rightTree = nodes - 1; rightTree >= 0; rightTree--) {
                leftTree = nodes - rightTree - 1;
                long iterations = CAT_NUMS[rightTree] * CAT_NUMS[leftTree];

                if (position >= current + iterations) {
                    current += iterations;
                } else {
                    // Start right tree at the start of the previous node set
                    rightTreePos = sumCats(0, rightTree - 1);
                    leftTreePos = sumCats(0, leftTree - 1);
                    for (int i = 0; i < iterations; i++) {
                        if (current == position) {
                            left = getTree(leftTreePos);
                            right = getTree(rightTreePos);
                            stop = true;
                            break;
                        }
                        current++;
                        rightTreePos++;
                        if (rightTreePos >= sumCats(0, rightTree)) {
                            rightTreePos = sumCats(0, rightTree - 1);
                            leftTreePos++;
                        }
                    }
                    if (stop == true) {
                        break;
                    }
                }

            }
            out = "(" + left + ")X(" + right + ")";
        } else {
            // fetch from memoised HashMap
            out = memoise.get((nodes))[(int) position];
        }
        return out;
    }

    /**
     * Returns the size of the set of trees up to annd including n nodes
     */
    public static int sumCats(int start, int end) {
        int out = 0;
        for (int i = start; i <= end; i++) {
            out += CAT_NUMS[i];
        }
        return out;
    }

    public static int inversePosition(int n) {
        if (n == 0) {
            return 0;
        }
        int previous = 0;
        int range = 0;
        for (int l : CAT_NUMS) {
            range += l;
            if (n >= previous && n < range) {
                n = n - previous;
                n = range - n - 1;
                break;
            } else {
                previous = range;
            }
        }
        return (int) n;
    }

    public static void main(String[] argv) throws IOException {
        process(new Reader(), System.out);
    }

    public static void process(Reader in, PrintStream out) throws IOException {
        int N = in.nextInt();
        getStartStates();
        for (int i = 1; i <= N; i++) {
            processCase(in, out, i);
        }
    }

    public static long binomialCoefficient(int n, int k) {
        long output = 1;
        if (k > n - k) {
            k = n - k;
        }
        for (int i = 0; i < k; ++i) {
            output = output * (n - i);
            output = output / (i + 1);
        }
        return output;
    }

    // catalan number n = (2*n)C(n) * (1/(n+1))
    public static long genCatalanNumber(int n) {
        long bc = binomialCoefficient(2 * n, n);
        return bc / (1 + n);
    }

    public static long factorial(long n) {
        if (n == 0)
            return 1;
        else
            return (n * factorial(n - 1));
    }

    public static int[] getCats() {

        int[] cats = new int[] { 1, 1, 2, 5, 14, 42, 132, 429, 1430, 4862, 16796, 58786, 208012, 742900, 2674440,
                9694845, 35357670, 129644790, 477638700, 1767263190 };
        return cats;
    }

    // Store some start states
    public static void getStartStates() {
        memoise.put(0, new String[] { "" });
        memoise.put(1, new String[] { "X" });
        memoise.put(2, new String[] { "X(X)", "(X)X" });
        memoise.put(3, new String[] { "X(X(X))", "X((X)X)", "(X)X(X)", "(X(X))X", "((X)X)X" });
        memoise.put(4,
                new String[] { "X(X(X(X)))", "X(X((X)X))", "X((X)X(X))", "X((X(X))X)", "X(((X)X)X)", "(X)X(X(X))",
                        "(X)X((X)X)", "(X(X))X(X)", "((X)X)X(X)", "(X(X(X)))X", "(X((X)X))X", "((X)X(X))X",
                        "((X(X))X)X", "(((X)X)X)X" });
        memoise.put(5, new String[] { "X(X(X(X(X))))", "X(X(X((X)X)))", "X(X((X)X(X)))", "X(X((X(X))X))",
                "X(X(((X)X)X))", "X((X)X(X(X)))", "X((X)X((X)X))", "X((X(X))X(X))", "X(((X)X)X(X))", "X((X(X(X)))X)",
                "X((X((X)X))X)", "X(((X)X(X))X)", "X(((X(X))X)X)", "X((((X)X)X)X)", "(X)X(X(X(X)))", "(X)X(X((X)X))",
                "(X)X((X)X(X))", "(X)X((X(X))X)", "(X)X(((X)X)X)", "(X(X))X(X(X))", "(X(X))X((X)X)", "((X)X)X(X(X))",
                "((X)X)X((X)X)", "(X(X(X)))X(X)", "(X((X)X))X(X)", "((X)X(X))X(X)", "((X(X))X)X(X)", "(((X)X)X)X(X)",
                "(X(X(X(X))))X", "(X(X((X)X)))X", "(X((X)X(X)))X", "(X((X(X))X))X", "(X(((X)X)X))X", "((X)X(X(X)))X",
                "((X)X((X)X))X", "((X(X))X(X))X", "(((X)X)X(X))X", "((X(X(X)))X)X", "((X((X)X))X)X", "(((X)X(X))X)X",
                "(((X(X))X)X)X", "((((X)X)X)X)X" });
        memoise.put(6, new String[] { "X(X(X(X(X(X)))))", "X(X(X(X((X)X))))", "X(X(X((X)X(X))))", "X(X(X((X(X))X)))",
                "X(X(X(((X)X)X)))", "X(X((X)X(X(X))))", "X(X((X)X((X)X)))", "X(X((X(X))X(X)))", "X(X(((X)X)X(X)))",
                "X(X((X(X(X)))X))", "X(X((X((X)X))X))", "X(X(((X)X(X))X))", "X(X(((X(X))X)X))", "X(X((((X)X)X)X))",
                "X((X)X(X(X(X))))", "X((X)X(X((X)X)))", "X((X)X((X)X(X)))", "X((X)X((X(X))X))", "X((X)X(((X)X)X))",
                "X((X(X))X(X(X)))", "X((X(X))X((X)X))", "X(((X)X)X(X(X)))", "X(((X)X)X((X)X))", "X((X(X(X)))X(X))",
                "X((X((X)X))X(X))", "X(((X)X(X))X(X))", "X(((X(X))X)X(X))", "X((((X)X)X)X(X))", "X((X(X(X(X))))X)",
                "X((X(X((X)X)))X)", "X((X((X)X(X)))X)", "X((X((X(X))X))X)", "X((X(((X)X)X))X)", "X(((X)X(X(X)))X)",
                "X(((X)X((X)X))X)", "X(((X(X))X(X))X)", "X((((X)X)X(X))X)", "X(((X(X(X)))X)X)", "X(((X((X)X))X)X)",
                "X((((X)X(X))X)X)", "X((((X(X))X)X)X)", "X(((((X)X)X)X)X)", "(X)X(X(X(X(X))))", "(X)X(X(X((X)X)))",
                "(X)X(X((X)X(X)))", "(X)X(X((X(X))X))", "(X)X(X(((X)X)X))", "(X)X((X)X(X(X)))", "(X)X((X)X((X)X))",
                "(X)X((X(X))X(X))", "(X)X(((X)X)X(X))", "(X)X((X(X(X)))X)", "(X)X((X((X)X))X)", "(X)X(((X)X(X))X)",
                "(X)X(((X(X))X)X)", "(X)X((((X)X)X)X)", "(X(X))X(X(X(X)))", "(X(X))X(X((X)X))", "(X(X))X((X)X(X))",
                "(X(X))X((X(X))X)", "(X(X))X(((X)X)X)", "((X)X)X(X(X(X)))", "((X)X)X(X((X)X))", "((X)X)X((X)X(X))",
                "((X)X)X((X(X))X)", "((X)X)X(((X)X)X)", "(X(X(X)))X(X(X))", "(X(X(X)))X((X)X)", "(X((X)X))X(X(X))",
                "(X((X)X))X((X)X)", "((X)X(X))X(X(X))", "((X)X(X))X((X)X)", "((X(X))X)X(X(X))", "((X(X))X)X((X)X)",
                "(((X)X)X)X(X(X))", "(((X)X)X)X((X)X)", "(X(X(X(X))))X(X)", "(X(X((X)X)))X(X)", "(X((X)X(X)))X(X)",
                "(X((X(X))X))X(X)", "(X(((X)X)X))X(X)", "((X)X(X(X)))X(X)", "((X)X((X)X))X(X)", "((X(X))X(X))X(X)",
                "(((X)X)X(X))X(X)", "((X(X(X)))X)X(X)", "((X((X)X))X)X(X)", "(((X)X(X))X)X(X)", "(((X(X))X)X)X(X)",
                "((((X)X)X)X)X(X)", "(X(X(X(X(X)))))X", "(X(X(X((X)X))))X", "(X(X((X)X(X))))X", "(X(X((X(X))X)))X",
                "(X(X(((X)X)X)))X", "(X((X)X(X(X))))X", "(X((X)X((X)X)))X", "(X((X(X))X(X)))X", "(X(((X)X)X(X)))X",
                "(X((X(X(X)))X))X", "(X((X((X)X))X))X", "(X(((X)X(X))X))X", "(X(((X(X))X)X))X", "(X((((X)X)X)X))X",
                "((X)X(X(X(X))))X", "((X)X(X((X)X)))X", "((X)X((X)X(X)))X", "((X)X((X(X))X))X", "((X)X(((X)X)X))X",
                "((X(X))X(X(X)))X", "((X(X))X((X)X))X", "(((X)X)X(X(X)))X", "(((X)X)X((X)X))X", "((X(X(X)))X(X))X",
                "((X((X)X))X(X))X", "(((X)X(X))X(X))X", "(((X(X))X)X(X))X", "((((X)X)X)X(X))X", "((X(X(X(X))))X)X",
                "((X(X((X)X)))X)X", "((X((X)X(X)))X)X", "((X((X(X))X))X)X", "((X(((X)X)X))X)X", "(((X)X(X(X)))X)X",
                "(((X)X((X)X))X)X", "(((X(X))X(X))X)X", "((((X)X)X(X))X)X", "(((X(X(X)))X)X)X", "(((X((X)X))X)X)X",
                "((((X)X(X))X)X)X", "((((X(X))X)X)X)X", "(((((X)X)X)X)X)X" });
    }
}