import java.io.PrintStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.StringTokenizer;

import java.io.IOException;

public class Main {
    public static void processCase(Reader in, PrintStream out, int iteration) throws IOException {
        String output = "";
        int m = in.nextInt();
        int p = in.nextInt();
        Node[] vertices = new Node[m];
        boolean isBalanced = false;

        // Create Nodes
        for (int i = 0; i < m; i++) {
            vertices[i] = new Node(i + 1, m);
        }
        // Set positive edges
        for (int i = 0; i < p; i++) {
            int from = in.nextInt();
            int to = in.nextInt();
            vertices[from - 1].setPositiveEdge(to);
            vertices[to - 1].setPositiveEdge(from);
        }
        if (m <= 2) {
            out.println("" + iteration + ": " + m);
            return;
        }
        // Check if balanced for each size from m downwards
        while (m > 2 && isBalanced == false) {
            isBalanced = checkTriangles(vertices, m);
            m--;
        }
        output = "" + (m + 1);

        out.println("" + iteration + ": " + output);
    }

    public static boolean checkTriangles(Node[] vertices, int n) {
        LinkedList<HashSet<Integer>> tabooNodes = new LinkedList<>();
        // Generate list of nodes to be left out
        int tabooSize = vertices.length - n;
        int[] verticesIndices = new int[vertices.length];
        for (int i = 0; i < vertices.length; i++) {
            verticesIndices[i] = i + 1;
        }
        int[] data = new int[tabooSize];
        return genTaboo(vertices, verticesIndices, tabooSize, 0, data, 0);
    }

    /**
     * 
     * @param vertices
     * @param arr
     * @param r
     * @param index
     * @param data
     * @param i
     * @return
     */
    static boolean genTaboo(Node[] vertices, int arr[], int r, int index, int data[], int i) {
        int n = arr.length;
        if (index == r) {
            HashSet<Integer> temp = new HashSet<>();
            for (int j = 0; j < r; j++) {
                temp.add(data[j]);
            }
            if (!temp.contains(1)) {
                return triangesWithoutNodes(vertices, temp);
            }
            return false;
        }
        if (i >= n) {
            return false;
        }
        data[index] = arr[i];
        if (genTaboo(vertices, arr, r, index + 1, data, i + 1) == true) {
            return true;
        }
        if (genTaboo(vertices, arr, r, index, data, i + 1) == true) {
            return true;
        }

        return false;
    }

    public static boolean triangesWithoutNodes(Node[] vertices, HashSet<Integer> tabooNodes) {
        for (int i = 0; i < vertices.length; i++) {
            for (int j = i + 1; j < vertices.length; j++) {
                for (int k = j + 1; k < vertices.length; k++) {
                    if (!tabooNodes.contains(i + 1) && !tabooNodes.contains(j + 1) && !tabooNodes.contains(k + 1)) {
                        // Check if triangle is negative
                        int balance = vertices[i].getEdge(j + 1) * vertices[j].getEdge(k + 1)
                                * vertices[k].getEdge(i + 1);
                        // if triangle is negative, return false
                        if (balance == -1) {
                            return false;
                        }
                    }
                }
            }
        }
        // No negative triangle was detected
        return true;
    }

    public static void process(Reader in, PrintStream out) throws IOException {
        int N = in.nextInt();
        for (int i = 1; i <= N; i++) {
            processCase(in, out, i);
        }
    }

    public static void main(String[] argv) throws IOException {
        process(new Reader(), System.out);
    }
}

class Node {
    private int index;
    private HashMap<Integer, Integer> edges;

    public Node(int i, int s) {
        index = i;
        edges = new HashMap<>();
        for (int f = 1; f <= s; f++) {
            edges.put(f, -1);
        }
        edges.put(index, 1);
    }

    public void setPositiveEdge(int i) {
        edges.put(i, 1);
    }

    public int getEdge(int e) {
        return edges.get(e);
    }

    public int getIndex() {
        return index;
    }
}