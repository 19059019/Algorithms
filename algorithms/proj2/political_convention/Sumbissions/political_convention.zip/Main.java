import java.io.PrintStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;
import java.io.IOException;

public class Main {
    private static char SAME = '~';
    private static char DIFF = '*';

    public static void processCase(Reader in, PrintStream out) throws IOException {
        HashMap<Integer, Vertex> delegates = new HashMap<>();
        HashSet<Integer> visited;
        int d = in.nextInt();
        int m = in.nextInt();
        int opp, x, y, tempOut;
        Vertex vertX, vertY;

        for (int i = 0; i < m; i++) {
            visited = new HashSet<Integer>();
            opp = in.nextInt();
            x = in.nextInt();
            y = in.nextInt();
            tempOut = -2;
            // System.out.printf("%d %d %d\n", opp, x, y);

            if (!delegates.containsKey(x)) {
                delegates.put(x, new Vertex(x));
            }
            if (!delegates.containsKey(y)) {
                delegates.put(y, new Vertex(y));
            }

            vertX = delegates.get(x);
            vertY = delegates.get(y);

            switch (opp) {
            case 1:
                // sameParty statement
                if (vertX.addConnection(vertY, SAME) == -1 || vertY.addConnection(vertX, SAME) == -1) {
                    tempOut = -1;
                }
                break;
            case 2:
                // diffParty statement
                if (vertX.addConnection(vertY, DIFF) == -1 || vertY.addConnection(vertX, DIFF) == -1) {
                    tempOut = -1;
                }
                break;
            case 3:
                // isSame question
                tempOut =  vertX.dfs(y, visited, ' ');
                break;
            case 4:
                // isDiff
                tempOut =  vertX.dfs(y, visited, ' ');
                if (tempOut == 1) {
                    tempOut = 0;
                } else if (tempOut == 0){
                    tempOut = 1;
                }
                break;
            }
            // for (Vertex v : delegates.values()) {
            //     System.out.println(v);
            // }
            if (tempOut > -2) {
                System.out.println(tempOut);
            }
        }
    }

    public static void process(Reader in, PrintStream out) throws IOException {
        int N = in.nextInt();
        for (int i = 1; i <= N; i++) {
            out.println(i + ":");
            processCase(in, out);
        }
    }

    public static void main(String[] argv) throws IOException {
        process(new Reader(), System.out);
    }

}

class Vertex {
    private char SAME = '~';
    private char DIFF = '*';
    private HashMap<Integer, Edge> connections;
    private int index;

    public Vertex(int index) {
        this.index = index;
        connections = new HashMap<Integer, Edge>();
    }

    /**
     * 
     * @param v   Vertex to connect to
     * @param rel Relationship ~[same]/*[diff]
     */
    public int addConnection(Vertex v, char rel) {
        char oldRelChar = ' ';
        int oldRel = dfs(v.getIndex(), new HashSet<Integer>(), ' ') ;
        if (oldRel == 1) {
            oldRelChar = SAME;
        } else {
            oldRelChar = DIFF;
        }
        // System.out.println("DFS: " + oldRel);
        if (oldRel == -1){
            connections.put(v.getIndex(), new Edge(v, rel));
            return 1;
        } else if (oldRelChar == rel) {
            return 1;
        } else {
            return -1;
        }
    }

    // Returns 1 for same, 0 for different and -1 for unknown
    public int dfs(int v, HashSet<Integer> visited, char rel) {
        for (Edge edge : connections.values()) {
            Vertex vertex = edge.getVertex();
            if (visited.contains(vertex.getIndex())) {
                continue;
            } else {
                // System.out.println("Visiting: "+vertex.getIndex());
                visited.add(this.index);
                if (rel != SAME && rel != DIFF) {
                    rel = edge.getRel();
                } else if (edge.getRel() == DIFF) {
                    if (rel == DIFF) {
                        rel = SAME;
                    } else {
                        rel = DIFF;
                    }
                }
                if (vertex.getIndex() == v) {
                    if (rel == SAME) {
                        return 1;
                    } else {
                        return 0;
                    }
                } else {
                    int out = vertex.dfs(v, visited, rel);
                    if (out != -1) {
                        return out;
                    }
                }
            }
        }
        return -1;
    }

    public HashMap<Integer, Edge> getConnections() {
        return this.connections;
    }

    public int getIndex() {
        return this.index;
    }

    @Override
    public String toString() {
        String out = index + ": ";
        for (Edge e : connections.values()) {
            out += e.getVertex().getIndex() + " " + e.getRel() + ", ";
        }
        return out;
    }
}

class Edge {
    private Vertex vertex;
    private char rel;

    public Edge(Vertex v, char rel) {
        this.vertex = v;
        this.rel = rel;
    }

    public Vertex getVertex() {
        return this.vertex;
    }

    public char getRel() {
        return this.rel;
    }

}